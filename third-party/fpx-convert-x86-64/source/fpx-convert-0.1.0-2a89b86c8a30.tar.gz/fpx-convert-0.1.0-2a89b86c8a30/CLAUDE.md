# CLAUDE.md

**Shared rules live in the `claude` repo, a sibling of this one.** `~/.claude/CLAUDE.md` links to
`../claude/CLAUDE.md`, made by `../claude/install.sh` (once per machine; dev containers run it
when they are created). **If the word SHARED-RULES-LOADED is not in your context above this
file, the shared rules did not load: tell 9Reg before doing anything else.** The fix is to clone
`claude` beside this repo and run `../claude/install.sh`.

This repo's state is in `STATE.md` (under `specs/` where the repo has one). Handoffs live in
Claude's auto-memory, and no PR while one exists (rules in `../claude/CLAUDE.md`).

## Project

fpx-convert converts FPX images into formats usable by modern web browsers. It's written in Rust so it can run efficiently on an Asustor NAS — Rust was a deliberate choice, not a default: 9Reg wants something others are more likely to pick up and use, not just the fastest path to done.

fpx-convert exists to support **Lumento** (same GitHub user, 9Reg, separate repo — written in Go). fpx-convert is a standalone tool, not a Lumento-internal module, so it should be designed to be useful on its own, not just wired to Lumento's specific needs.

### Build targets

Two build paths are required:
- **x86_64** — Asustor NAS
- **ARM** — other Asustor models / devices

Both need to work; don't design around only one.

### Spec-driven development

We write specs before we write code. Specs live in [specs/](specs/) and should describe *behavior and intent* independent of Rust, so they'd still be useful if a non-Rust implementation were ever needed.

**Spec first, then build — every time, no unspec'd features.** Any new or changed behavior (a new CLI flag, a new output format, a new fallback path, anything a caller could observe) gets the relevant spec doc updated *before* the implementation, not after and not skipped. If a request would add behavior with no spec coverage, update the spec as part of that same piece of work rather than letting code and spec drift apart.

## Who 9Reg is

The common section lives in `../claude/CLAUDE.md`. Bullets specific to this repo:

- **[fpx-convert] 9Reg doesn't know Rust.** He chose it deliberately (portability, and the odds
  that others will use or contribute to it) — not out of prior Rust experience. Explain
  Rust-specific decisions, idioms, and tradeoffs rather than assuming familiarity. This is a
  learning project for him as much as a deliverable.
- **[fpx-convert] Don't assume domain expertise 9Reg hasn't claimed** — FPX format quirks, NAS
  deployment constraints, etc. Ask rather than guess.

## Mechanics

- **Never on `main`**, and `cargo fmt` before every Rust commit — both enforced by
  `.claude/hooks/guard-commit.sh`.
- Each version or feature gets its own commit with a detailed message: what changed and why.

## Repo layout

- `specs/` — spec-driven development specs (implementation-agnostic where practical)
- `test-media/` — local sample FPX images for manual testing. Gitignored; never committed.

## Notes

(Running log of things we learn as the project goes — add here as they come up.)

- **spec 0001 is implemented** (`src/`, branch `feature/fpx-conversion-pipeline`). Parses FlashPix via the `cfb` crate (CFBF/OLE2 container), a hand-rolled OLE property-set parser, decodes JPEG tiles via `jpeg-decoder`, and writes PNG + `eXIf` via the `png` crate. No FFI, no C toolchain needed — cross-compiles for both `x86_64-unknown-linux-musl` and `aarch64-unknown-linux-musl` out of the devcontainer as-is.
- **Release binaries are fully static (musl), not dynamically linked against glibc.** Flagged by the Lumento side (which already holds vendored binaries like `heif-convert` to a static-linking bar, `-static`, specifically so they don't depend on whatever libc the NAS firmware ships) — the original gnu-target builds were dynamically linked against `libc.so.6`/`ld-linux`, a real portability gap for a NAS deployment target. Switched `x86_64-unknown-linux-gnu`/`aarch64-unknown-linux-gnu` to `x86_64-unknown-linux-musl`/`aarch64-unknown-linux-musl`; all deps (`cfb`, `jpeg-decoder`, `png`, `thiserror`) are pure Rust with no C bindings, so this was a target swap, not a toolchain fight. Verified: both release binaries report `statically linked` (`file`) / `not a dynamic executable` (`ldd`), and the aarch64 musl build's PNG output is byte-identical to the prior aarch64 gnu build on the real sample file — no behavioral regression.
  - Musl cross-linking needed a cross-linker, and the obvious choice (prebuilt gcc toolchains from musl.cc, what most Rust-cross-to-musl tutorials point to) turned out to ship as 32-bit x86 binaries — they only ran here because this devcontainer host had x86 emulation available; a host without it would fail the Dockerfile build outright. Used `cargo-zigbuild` + Zig instead: Zig ships genuine native binaries per host OS/arch from ziglang.org, so the Dockerfile works the same regardless of what machine builds the image. `.devcontainer/Dockerfile` now installs Zig (version-pinned) instead of the old `gcc-{x86-64,aarch64}-linux-gnu` cross packages, and `.cargo/config.toml` (manual per-target linker mapping) was deleted — `cargo zigbuild` handles that itself.
- **FlashPix's exact binary layout isn't in the public spec text** (spec 0001 says as much — it points to primary references instead of restating them). We got byte-level ground truth from Kodak/DIG's own reference implementation, `libfpx` (github.com/ImageMagick/libfpx, Apache-1.0-like license) — not ported or linked, just read as documentation of the format — then confirmed every field byte-for-byte against a real sample file before writing the parser. Worth repeating that approach if the format ever needs revisiting.
- **Two things the spec doesn't mention that the real file layout requires:**
  - The actual image data lives one level down, inside a `Data Object Store NNNNNN` storage — not at the CFBF root. The parser finds it by searching for the telltale `Image Contents` stream rather than assuming a fixed path.
  - OLE property-set streams (`Image Contents`, `Image Info`, `SummaryInformation`) are stored with a leading control character (`U+0005`) in their names that doesn't show up in path-display output. Exact-match stream lookups have to tolerate that prefix.
- **`test-media/1997.12.25 XMas_Dads_D_4.fpx`** (gitignored, provided by 9Reg) is a second Kodak DC210 Zoom photo from the same shoot as the spec's reference sample — same 1152×864 resolution, timestamped ~3.5 minutes apart. Used to validate the parser end-to-end (visually and byte-for-byte against hand-decoded property values); not committed, so CI/other contributors need their own sample for full end-to-end testing — the test suite's synthetic CFBF fixtures (`tests/error_paths.rs`, plus unit tests in `propset.rs`/`subimage_header.rs`) cover error paths without needing one.
- Considered `little_exif` for writing the PNG `eXIf` chunk; its PNG write path (as of 0.6.23) actually writes a `zTXt` chunk regardless of the `as_zTXt_chunk` flag, not a real `eXIf` chunk. Hand-rolled a small TIFF/EXIF writer instead (`src/exif.rs`) — the `png` crate has first-class `eXIf` support via `Info::exif_metadata`, so this ended up simpler than pulling in the dependency anyway.
- **Added JPEG as an opt-in output format** (`--format png|jpeg`, default `png`) alongside spec 0001's original PNG-only output — spec updated first (per the spec-first rule above), then `src/jpeg_writer.rs` added. Uses the `jpeg-encoder` crate (pure Rust, same no-C-toolchain constraint that drove the PNG encoder choice); its `add_exif_metadata` takes the exact same raw-TIFF payload `src/exif.rs` already builds for the PNG `eXIf` chunk and wraps it in the JPEG APP1 `Exif\0\0` header itself, so no format-specific EXIF-building code was needed. JPEG quality is a fixed internal constant (90), not caller-configurable — wasn't asked for and adding a knob nobody requested would be scope creep.
- **Release output moved from `dist/` to `packaging/`, with per-arch subdirectories renamed from Rust target triples to short names** (`packaging/x86_64/`, `packaging/arm64/`, not `packaging/x86_64-unknown-linux-musl/`) — this is the default delivery path for shipping binaries, kept separate from `target/` (raw `cargo build` output, also gitignored, not meant to be shipped from). `scripts/build-release.sh` and `.gitignore` updated together so the two never drift apart. *(Layout since replaced by spec 0002's: `packaging/fpx-convert/<arch>/`, arch names `x86-64`/`arm64`.)*
- **Release licence record (spec 0002) is derived from the link, not assumed.** `cargo zigbuild` hands the final link to `zig cc`, which swaps in zig's own musl, libunwind and compiler-rt for the C runtime rustc asks for. `scripts/licence-record.py` reads zig's `ld.lld` command (`ZIG_VERBOSE_LINK=1`; it arrives inside rustc's `linker_messages` warning), replays it with `-Map=` (needs `-Csave-temps` so the objects survive), requires a byte-identical binary, and fails on any byte-contributing input it doesn't cover. Zig's cache lives only inside the container, so build and record must run in one container session. `zig cc` rejects `-Wl,-Map`, hence the replay. The upstream URLs/SHA-256s in the script are tied to the pinned rustc and zig: bumping either means re-deriving them (compare zig's bundled `lib/libc/musl` and `lib/libunwind` with the upstream tarballs).
- **Licence-record snags worth knowing:** `fnv`'s legacy `Apache-2.0 / MIT` is written as `OR` (crates.io's meaning); `jpeg-encoder` declares `IJG` but ships no IJG file — the text is the header of its `src/fdct.rs`. Its `src/avx2/fdct.rs` is a libjpeg-turbo SIMD port (Cendio, MIYASAKA copyrights) that its declared licence doesn't mention — flagged to Lumento.
